» npm run perf

{ 'ngraph.pagerank': '0.1.4',
  npm: '3.10.10',
  ares: '1.10.1-DEV',
  cldr: '30.0.2',
  http_parser: '2.7.0',
  icu: '58.1',
  modules: '51',
  node: '7.2.1',
  openssl: '1.0.2j',
  tz: '2016g',
  unicode: '9.0',
  uv: '1.10.1',
  v8: '5.4.500.44',
  zlib: '1.2.8' }
Epsilon 1e-7 x 65.16 ops/sec ±2.36% (67 runs sampled)
Epsilon 1e-10 x 49.31 ops/sec ±1.40% (63 runs sampled)
Fastest is Epsilon 1e-7
