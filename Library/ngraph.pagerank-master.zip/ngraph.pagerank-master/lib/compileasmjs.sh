emcc -g ./native.cpp
